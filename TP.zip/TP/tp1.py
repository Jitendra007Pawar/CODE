import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

data_set = pd.read_csv('PimaIndiansDiabetes.csv')
X = data_set.iloc[:, :-1]   # Independent Variables separated as X
y = data_set.iloc[:, -1]    # Dependent Variables into y

print(X.isnull().any())
print(y.isnull().any())
print(X.info())

X = X.values
y = y.values

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0) 

from sklearn.preprocessing import StandardScaler,LabelEncoder
scaler_X = StandardScaler()
X_train = scaler_X.fit_transform(X_train)
X_test = scaler_X.transform(X_test)

from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_train, y_train)

y_pred = classifier.predict(X_test)

from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
print(cm)



