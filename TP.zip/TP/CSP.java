import java.util.*;

public class CSP
{
    static int N;
    public static void main(String args[])
    {
        Scanner sc= new Scanner(System.in);
        N = sc.nextInt();
        solve();
    }

    public static boolean check(int row,int col,int slash[][],int rslash[][],boolean rLookup[],boolean bslash[],boolean brslash[])
    {
        if(rLookup[row] || bslash[slash[row][col]] || brslash[rslash[row][col]])
        {
            return false;
        }
        return true;
    }


    public static boolean dowork(int arr[][],int col,int slash[][],int rslash[][],boolean rLookup[],boolean bslash[],boolean brslash[])
    {
        if(col>=N)
        {
            return true;
        }

        for(int i=0;i<N;i++)
        {
            if(check(i,col,slash,rslash,rLookup,bslash,brslash))
            {
                arr[i][col] = 1;
                rLookup[i] = true;
                bslash[slash[i][col]] = true;
                brslash[rslash[i][col]] = true;

                if(dowork(arr,col+1, slash, rslash, rLookup, bslash, brslash))
                {
                    return true;
                }

                arr[i][col] = 0;
                rLookup[i] = false;
                bslash[slash[i][col]] = false;
                brslash[rslash[i][col]] = false;
            }
        }
        return false;
    }

    public static void solve()
    {
        int arr[][]= new int[N][N];
        int slash[][] = new int[N][N];
        int rslash[][] = new int[N][N];

        boolean rLookup[] = new boolean[N];
        for(int i=0;i<N;i++)
        {
            rLookup[i] = false;
        }

        boolean bslash[] = new boolean[2*N-1];
        for(int i=0;i<2*N-1;i++)
        {
            bslash[i] = false;
        }

        boolean brslash[] = new boolean[2*N-1];
        for(int i=0;i<2*N-1;i++)
        {
            brslash[i] = false;
        }

        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
            {
                slash[i][j] = i+j;
                rslash[i][j] = i-j+N-1;
            }
        }

        if(dowork(arr,0,slash,rslash,rLookup,bslash,brslash)==false)
        {
            System.out.println("not possible");
            return;
        }

        printSolution(arr);
        
    }
    
    public static void printSolution(int arr[][])
    {
        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
            {
                System.out.print(arr[i][j]+" ");
            }
            System.out.println();
        }
    }
}
