import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 
from sklearn.preprocessing import LabelEncoder

data = pd.read_csv('triphistory.csv')
data = data.drop(['Duration', 'Start date', 'End date','Bike#'],axis=1)
cols = data.columns 
print(cols)

le = LabelEncoder()
le.fit(data['Member Type'])
data['Member Type'] = le.transform(data['Member Type'])

le.fit(data['Start station'])
data['Start station'] = le.transform(data['Start station'])

le.fit(data['End station'].astype(str))
data['End station'] = le.transform(data['End station'].astype(str))

print(data.head())

X = data.iloc[:,:-1]
Y = data.iloc[:,-1]

from sklearn.model_selection import train_test_split
X_train,X_test,Y_train,Y_test = train_test_split(X,Y,random_state=0,test_size=0.25)

from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_train,Y_train)

print(classifier.score(X_test,Y_test)*100)

