
#include<time.h>
#include<omp.h>
#include<vector>
#include <stdlib.h>//////////////////////////////////////MUST
#include<stdio.h>////////////////////////////////////////MUST
using namespace std;
vector<int>initialize(vector<int>v,int); 
int main()
{
	int size=1<<20;
	int arr[size];
	vector<int> v;
	v=initialize(v,size);
	double start,end;
	int x=0;
	vector<int>::iterator ptr;
	for(ptr=v.begin();ptr<v.end();ptr++)
	{
		arr[x]=*ptr;
		x++;
	}

	printf("REDUCTION FOR MAX\n");
	int max_val=0;
	start=omp_get_wtime();
	#pragma omp parallel for reduction (max:max_val)
	for(int j=0;j<size;j++)
	{
		if(arr[j]>max_val)
			max_val=arr[j];
	}
	printf("max===%d\n",max_val);

printf("REDUCTION FOR MIN\n");
	int min_val=9999;
	#pragma omp parallel for reduction (min:min_val)
	for(int j=0;j<size;j++)
	{
		if(arr[j]<min_val)
			min_val=arr[j];
	}
	printf("min=%d\n",min_val);

printf("REDUCTION FOR SUM\n");
	int sum=0;
	#pragma omp parallel for reduction (+:sum)
	for(int j=0;j<size;j++)
	{
		sum=sum+arr[j];
	}
	printf("sum=%d\n",sum);

printf("REDUCTION FOR AVG\n");
 sum=0;
	#pragma omp parallel for reduction (+:sum)
	for(int j=0;j<size;j++)
	{sum=sum+arr[j];
	}
	printf("average==%d\n",(sum/size));
	end=omp_get_wtime();
	printf("Time required for reduction :%f",(end-start));
}
vector<int> initialize(vector<int> v,int n)
{
    srand(time(0));
    for(int i=0;i<n;i++)
        v.push_back(rand()%10000);


    return v;

}
///                FOR THIS WE USE "g++ -fopenmp a1.c -o a1"
//////////////                                                                                                          "./a1"
