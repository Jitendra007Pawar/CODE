import java.util.*;

public class CSP1
{
    static int N;
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        N = sc.nextInt();
        solve();
    }

    public static void printSolution(int arr[][])
    {
        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
            {
                System.out.print(arr[i][j]+"  ");
            }
            System.out.println();
        }
    }

    public static void solve()
    {
        int arr[][] = new int[N][N];
        int splashCode[][] = new int[N][N];
        int backsplashCode[][] = new int[N][N];

        boolean row[] = new boolean[N];

        for(int i=0;i<N;i++)
        {
            row[i] = false;
        }

        boolean backsplashBoolean[] = new boolean[2*N-1];
        for(int i=0;i<2*N-1;i++)
        {
            backsplashBoolean[i] = false;
        }

        boolean splashBoolean[] = new boolean[2*N-1];
        for(int i=0;i<2*N-1;i++)
        {
            splashBoolean[i] = false;
        }

        for(int i=0;i<N;i++)
        {
            for(int j=0;j<N;j++)
            {
                arr[i][j] = 0;
                splashCode[i][j] = i+j;
                backsplashCode[i][j] = i-j+N-1; 
            }
        }

        if(solveNew(arr,0,splashCode,backsplashCode,row,splashBoolean,backsplashBoolean)==false)
        {
            System.out.println("Solution not possible");
            return;
        }

        printSolution(arr);
        return;
    }

    public static boolean check(int row,int col,int splash[][],int backsplash[][],boolean rowUp[],boolean splashBoolean[],boolean backsplashBoolean[])
    {
        if(rowUp[row] || splashBoolean[splash[row][col]] || backsplashBoolean[backsplash[row][col]])
        {
            return false;
        }
        return true;
    }


    public static boolean solveNew(int arr[][],int col,int splash[][],int backsplash[][],boolean row[],boolean splashBoolean[],boolean backsplashBoolean[])
    {
        if(col>=N)
        {
            return true;
        }

        for(int i=0;i<N;i++)
        {
            if(check(i,col,splash,backsplash,row,splashBoolean,backsplashBoolean))
            {
                arr[i][col] =1;
                splashBoolean[splash[i][col]] = true;
                backsplashBoolean[backsplash[i][col]]  =true;
                row[i] = true;

                if(solveNew(arr,col+1,splash,backsplash,row,splashBoolean,backsplashBoolean))
                {
                    return true;
                }

                arr[i][col] = 0;
                splashBoolean[splash[i][col]] = false;
                backsplashBoolean[backsplash[i][col]]  = false;
                row[i] = false;
            }
        }
        return false;
    }

}