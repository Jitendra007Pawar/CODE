public class GraphBean
{
    int state[][];
    int fn;
    int gn;
    int hn;

    GraphBean()
    {
        fn = gn = hn =0;
    }

    public String toString()
    {
        String str= new String();

        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                str += "\t" + state[i][j];
            }
            str+="\n";
        }
        return str;
    }
}