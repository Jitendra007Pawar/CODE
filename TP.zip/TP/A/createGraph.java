import java.util.*;
public class createGraph
{
    GraphBean goal = new GraphBean();
    Scanner sc = new Scanner(System.in);
    ArrayList<GraphBean> queue = new ArrayList<>();

    public int[][] acceptArray()
    {
        int arr[][] = new int[3][3];
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++)
            {
                arr[i][j] = sc.nextInt();
            }
        }
        return arr;
    }

    public void acceptGraph()
    {
        GraphBean start = new GraphBean();
        System.out.println("Enter start state");
        start.state = acceptArray();
        System.out.println("Enter Goal state");
        goal.state = acceptArray();

        queue.add(start);
 
        System.out.println("Start state :- \n"+start.toString());
        System.out.println("Final state :- \n"+goal.toString());
    }

    public void algorithm()
    {
        Astar obj = new Astar();
        obj.initiate(queue,goal);
    }

}