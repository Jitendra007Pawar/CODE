import java.util.*;
public class Astar
{
    ArrayList<GraphBean> queue = new ArrayList<>();
    GraphBean goal;
    int state=0;
    int hValue[] = new int[4];

    public void initiate(ArrayList<GraphBean> q,GraphBean goal)
    {
        queue = q;
        this.goal = goal;
        int i=1;

        while(!stateReach())
        {
            System.out.println("Output Of iteration " + i);
            algoStep(i);
            i++;
            if(i==3)
            {
                break;
            }
        }   
    }


    public int[][] intializeTempArray()
    {
        int arr[][]= new int[3][3];

        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                arr[i][j] = queue.get(0).state[i][j];
            }
        }
        return arr;
    }

    public void algoStep(int i)
    {
        state = i;
        int arr[][];

        arr = intializeTempArray();
        arr = left(arr);
        hValue[0] = heuristicValue(arr);
        printIteration(arr);

        arr = intializeTempArray();
        arr = right(arr);
        hValue[1] = heuristicValue(arr);
        printIteration(arr);
        
        arr = intializeTempArray();
        arr = up(arr);
        hValue[2] = heuristicValue(arr);
        printIteration(arr);
        
        arr = intializeTempArray();
        arr = down(arr);
        hValue[3] = heuristicValue(arr);
        printIteration(arr);

        int min = 0;

        for(int k=0;k<4;k++)
        {
            if(hValue[k]<hValue[min])
            {
                min = k;
            }
        }

        if(min==0)
        {
            arr = left(queue.get(0).state);
        }
        else if(min==1)
        {
            arr = right(queue.get(0).state);
        }
        else if(min==2)
        {
            arr = up(queue.get(0).state);
        }
        else if(min==3)
        {
            arr = down(queue.get(0).state);
        }

        System.out.println("Selected Puzzle \n");
        queue.add(printIteration(arr));
    }


    public GraphBean printIteration(int arr[][])
    {
        GraphBean bean = new GraphBean();
        bean.state = arr;
        bean.gn = state;
        bean.hn = heuristicValue(arr);
        bean.fn = bean.gn + bean.hn;

        System.out.println("\n Puzzle :- \n"+bean.toString());
        System.out.println("g(n) :- "+bean.gn+"\t h(n) :- "+bean.hn+"\t f(n) :- "+bean.fn);
        return bean;
    }

    public int heuristicValue(int arr[][]){
        
        int count=0;
        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                if(arr[i][j] != goal.state[i][j] && arr[i][j]!=0)
                {
                    count++;
                }
            }
        }
        return count;
    }

    public boolean stateReach()
    {
        GraphBean  temp= queue.get(queue.size()-1);

        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                if(temp.state[i][j] != goal.state[i][j])
                {
                    return false;
                }
            }
        }
        return true;
    }

    public int[][] left(int arr[][])
    {
        int temp;
        int flag=0;

        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                if(arr[i][j]==0 && j!=0)
                {
                    temp = arr[i][j];
                    arr[i][j] = arr[i][j-1];
                    arr[i][j-1] = temp;
                    flag = 1;
                    break;
                }
            }
            if(flag==1)
            {
                break;
            }
        }
        return arr;
    }


    public int[][] right(int arr[][])
    {
        int temp;
        int flag=0;

        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                if(arr[i][j]==0 && j!=2)
                {
                    temp = arr[i][j];
                    arr[i][j] = arr[i][j+1];
                    arr[i][j+1] = temp;
                    flag = 1;
                    break;
                }
            }
            if(flag==1)
            {
                break;
            }
        }
        return arr;
    }

    public int[][] up(int arr[][])
    {
        int temp;
        int flag=0;

        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                if(arr[i][j]==0 && i!=0)
                {
                    temp = arr[i][j];
                    arr[i][j] = arr[i-1][j];
                    arr[i-1][j] = temp;
                    flag = 1;
                    break;
                }
            }
            if(flag==1)
            {
                break;
            }
        }
        return arr;
    }

    public int[][] down(int arr[][])
    {
        int temp;
        int flag=0;

        for(int i=0;i<3;i++)
        {
            for(int j=0;j<3;j++)
            {
                if(arr[i][j]==0 && i!=2)
                {
                    temp = arr[i][j];
                    arr[i][j] = arr[i+1][j];
                    arr[i+1][j] = temp;
                    flag = 1;
                    break;
                }
            }
            if(flag==1)
            {
                break;
            }
        }
        return arr;
    }


}