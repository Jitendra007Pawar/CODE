public class Intitiate
{
    public static void main(String args[])
    {
        createGraph gh = new createGraph();
        gh.acceptGraph();
        gh.algorithm();
    }
} 
