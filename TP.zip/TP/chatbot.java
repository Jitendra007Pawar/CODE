import java.util.*;

public class chatbot
{
    static HashMap<String,String> welcome = new HashMap<>();
    static HashMap<String,String> noun = new HashMap<>();
    static HashMap<String,String> end = new HashMap<>();
    
    public static void create()
    {
        welcome.put("hii","Welcome ! How can I help you ?");
        welcome.put("hello","hey , how can I help ?");
        welcome.put("hey","how to help you ?");
        
        noun.put("money","where ?");
        noun.put("finance","Many firm provide load option");
        noun.put("invest","Yes,Offcourse.Basically there are many options to invest.");
        noun.put("bank","Regional Or Investment Banks In which section would you like to invest");
        noun.put("share","which are this shares ?");
        noun.put("loan","which loan like HOusing Personal Educational or any other kind of the help");
        noun.put("investment","");   

        end.put("bye","bbye");
    }
    public static void main(String args[])
    {
        Scanner sc = new Scanner(System.in);
        create();

        while(true)
        {
            String ip = sc.nextLine();
            System.out.println(getOutput(ip));
        }
    }

    public static String getOutput(String str)
    {
        String arr[] = str.split("\\s");
        for(int i=0;i<arr.length;i++)
        {
            if(noun.containsKey(arr[i]))
            {
                return noun.get(arr[i]);
            }
            else if(welcome.containsKey(arr[i]))
            {
                return welcome.get(arr[i]);
            }
            else if(end.containsKey(arr[i]))
            {
                return end.get(arr[i]);
            }
        }
        return "I am not getting So Please enter again";
    }

}