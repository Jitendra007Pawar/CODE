public class ab
{
    static int scores[] = {4,6,7,9,1,2,0,1,0,1,9,2};
    public static void main(String args[])
    {
        System.out.println("Optimal max "+minmax(0,0,true,-1000,1000));
    }

    public static int minmax(int depth,int nodeNo,boolean maxBoolean,int alpha,int beta)
    {
        if(depth==3)
        {
            return scores[nodeNo];
        }

        if(maxBoolean)
        {
            int maxValue = -1000;
            for(int i=0;i<2;i++)
            {
                int val = minmax(depth+1, nodeNo*2+i,false, alpha, beta);
                maxValue = Math.max(maxValue, val);
                alpha = Math.max(alpha,maxValue);

                if(beta <= alpha)
                {
                    break;
                }
            }
            return maxValue;
        }
        else
        {
            int minValue = 1000;

            for(int i=0;i<2;i++)
            {
                int val = minmax(depth+1,nodeNo*2+i,true,alpha,beta);
                minValue = Math.min(minValue, val);
                beta = Math.min(minValue,beta);

                if(beta <= alpha)
                {
                    break;
                }
            }
            return minValue;
        }
    }



}