import pandas as pd
import os
import matplotlib.pyplot as plt

data = pd.read_csv('iris.csv',encoding='utf-8')
cols = data.columns

for i in range(1,6):
    feature = cols[i]
    print(data[feature].describe())
    print('\n\n')

print('\n\n')
for i in range(1,5):
    feature = cols[i]
    data[feature].plot(kind='hist',bins=150)
    plt.title(feature+" Destribution")
    plt.xlabel("Data on axis")
    plt.show()

print("Printing Box")
labels = []

for i in range(1,5):
    labels.append(cols[i])

data.drop(cols[0],1,inplace=True)
data.boxplot(labels)
plt.show()

